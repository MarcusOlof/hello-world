﻿namespace Library
{
    partial class ModifyBookCopyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.BookCopyTitleTxtBox = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.ModifyBookCopyNmrTxtBox = new System.Windows.Forms.TextBox();
            this.ModiftBookCopyBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title of book you want to modify copies";
            // 
            // BookCopyTitleTxtBox
            // 
            this.BookCopyTitleTxtBox.Location = new System.Drawing.Point(16, 34);
            this.BookCopyTitleTxtBox.Name = "BookCopyTitleTxtBox";
            this.BookCopyTitleTxtBox.Size = new System.Drawing.Size(393, 22);
            this.BookCopyTitleTxtBox.TabIndex = 1;
            this.BookCopyTitleTxtBox.TextChanged += new System.EventHandler(this.BookCopyTitleTxtBox_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Modify Copies to number:";
            // 
            // ModifyBookCopyNmrTxtBox
            // 
            this.ModifyBookCopyNmrTxtBox.Location = new System.Drawing.Point(16, 92);
            this.ModifyBookCopyNmrTxtBox.Name = "ModifyBookCopyNmrTxtBox";
            this.ModifyBookCopyNmrTxtBox.Size = new System.Drawing.Size(393, 22);
            this.ModifyBookCopyNmrTxtBox.TabIndex = 4;
            this.ModifyBookCopyNmrTxtBox.TextChanged += new System.EventHandler(this.ModifyBookCopyNmrTxtBox_TextChanged);
            // 
            // ModiftBookCopyBtn
            // 
            this.ModiftBookCopyBtn.Location = new System.Drawing.Point(16, 144);
            this.ModiftBookCopyBtn.Name = "ModiftBookCopyBtn";
            this.ModiftBookCopyBtn.Size = new System.Drawing.Size(393, 50);
            this.ModiftBookCopyBtn.TabIndex = 5;
            this.ModiftBookCopyBtn.Text = "Modify copies";
            this.ModiftBookCopyBtn.UseVisualStyleBackColor = true;
            this.ModiftBookCopyBtn.Click += new System.EventHandler(this.ModiftBookCopyBtn_Click);
            // 
            // ModifyBookCopyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(431, 228);
            this.Controls.Add(this.ModiftBookCopyBtn);
            this.Controls.Add(this.ModifyBookCopyNmrTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BookCopyTitleTxtBox);
            this.Controls.Add(this.label1);
            this.Name = "ModifyBookCopyForm";
            this.Text = "ModifyBookCopyForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BookCopyTitleTxtBox;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ModifyBookCopyNmrTxtBox;
        private System.Windows.Forms.Button ModiftBookCopyBtn;
    }
}