﻿namespace Library
{
    partial class AddMemberForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MemberNameTxtBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.MemberPersonalNmrTxtBox = new System.Windows.Forms.TextBox();
            this.MemberAddMemberBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MemberNameTxtBox
            // 
            this.MemberNameTxtBox.Location = new System.Drawing.Point(13, 62);
            this.MemberNameTxtBox.Name = "MemberNameTxtBox";
            this.MemberNameTxtBox.Size = new System.Drawing.Size(429, 22);
            this.MemberNameTxtBox.TabIndex = 0;
            this.MemberNameTxtBox.TextChanged += new System.EventHandler(this.MemberNameTxtBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "personal number";
            // 
            // MemberPersonalNmrTxtBox
            // 
            this.MemberPersonalNmrTxtBox.Location = new System.Drawing.Point(12, 124);
            this.MemberPersonalNmrTxtBox.Name = "MemberPersonalNmrTxtBox";
            this.MemberPersonalNmrTxtBox.Size = new System.Drawing.Size(429, 22);
            this.MemberPersonalNmrTxtBox.TabIndex = 3;
            this.MemberPersonalNmrTxtBox.TextChanged += new System.EventHandler(this.MemberPersonalNmrTxtBox_TextChanged);
            // 
            // MemberAddMemberBtn
            // 
            this.MemberAddMemberBtn.Location = new System.Drawing.Point(12, 170);
            this.MemberAddMemberBtn.Name = "MemberAddMemberBtn";
            this.MemberAddMemberBtn.Size = new System.Drawing.Size(430, 53);
            this.MemberAddMemberBtn.TabIndex = 4;
            this.MemberAddMemberBtn.Text = "Add Member";
            this.MemberAddMemberBtn.UseVisualStyleBackColor = true;
            this.MemberAddMemberBtn.Click += new System.EventHandler(this.MemberAddMemberBtn_Click);
            // 
            // AddMemberForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 262);
            this.Controls.Add(this.MemberAddMemberBtn);
            this.Controls.Add(this.MemberPersonalNmrTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MemberNameTxtBox);
            this.Name = "AddMemberForm";
            this.Text = "AddMemberForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox MemberNameTxtBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox MemberPersonalNmrTxtBox;
        private System.Windows.Forms.Button MemberAddMemberBtn;
    }
}