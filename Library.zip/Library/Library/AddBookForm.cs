﻿using Library.Models;
using Library.Repositories;
using Library.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    partial class AddBookForm : Form
    {
        BookService bookService;
        public AddBookForm(BookService bookService)
        {
            InitializeComponent();

            this.bookService = bookService;
        }
        /// <summary>
        /// Checking if the value in the textbox is the correct value
        /// </summary>
        /// <param name="s">
        /// a string from a textbox
        /// </param>
        public bool IsNumeric(string s)
        {
            float output;
            return float.TryParse(s, out output);
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
        }

        private void TitleTxtBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void ISBNTxtBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void DescriptionTxtBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void CopiesTxtBox_TextChanged(object sender, EventArgs e)
        {
        }
        /// <summary>
        /// Adds a book object to the database
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void addBookBtn_Click(object sender, EventArgs e)
        {
            AddBook();
            
            
        }
        /// <summary>
        /// method for adding a book to the database
        /// </summary>

        public void AddBook()
        {
            Author a = new Author();
            foreach (Book b in bookService.All())
            {
                if (b.Author.Name != AuthorTxtBox.Text)
                {
                    a = new Author()
                    {
                        Name = AuthorTxtBox.Text
                    };
                }
                else
                {
                    if (b.Author.Name == AuthorTxtBox.Text)
                    {
                        a = b.Author;
                    }
                }
            }

            ICollection<BookCopy> tempBookCopyList = new List<BookCopy>();
            if (TitleTxtBox.Text == "")
            {
                MessageBox.Show("Ingen bok kommer skapas eftersom du måste fylla i alla fält");
            }
            else if (ISBNTxtBox.Text == "")
            {
                MessageBox.Show("Ingen bok kommer skapas eftersom du måste fylla i alla fält");
            }
            else if (DescriptionTxtBox.Text == "")
            {
                MessageBox.Show("Ingen bok kommer skapas eftersom du måste fylla i alla fält");
            }
            else if (a == null)
            {
                MessageBox.Show("Ingen bok kommer skapas eftersom du måste fylla i alla fält");
            }
            else if (IsNumeric(CopiesTxtBox.Text) != true)
            {
                MessageBox.Show("Ingen bok kommer skapas eftersom det måste vara en siffra i copies textfältet");
            }
            else
            {
                int BookCopy = Int32.Parse(CopiesTxtBox.Text);

                Book book = new Book(TitleTxtBox.Text, ISBNTxtBox.Text, DescriptionTxtBox.Text, a);

            for (int i = 0; i < BookCopy; i++) // skapar så många kopior som användaren skriver
            {
                BookCopy bookCopy = new BookCopy()
                {
                    book1 = book
                };
                tempBookCopyList.Add(bookCopy);
            }
            book.BookCopyList = tempBookCopyList;
            bookService.AddBook(book);

                this.Hide();
            }
        }
    }
}
