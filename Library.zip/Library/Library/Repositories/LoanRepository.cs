﻿using Library.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Repositories
{
    class LoanRepository
    {
        LibraryContext context;

        public LoanRepository(LibraryContext c)
        {
            this.context = c;
        }

        public IEnumerable<Loan> All()
        {
            return context.Loans;
        }

        public void AddLoan(Loan l)
        {
            context.Loans.Add(l);
            context.SaveChanges();
        }

        public void DeleteLoan(Loan l)
        {
            context.Loans.Remove(l);
            context.SaveChanges();
        }

        public void Edit(Loan l)
        {
            context.SaveChanges();
        }
    }
}
