﻿using Library.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Repositories
{
    class AuthorRepository
    {
        LibraryContext context;

        public AuthorRepository(LibraryContext c)
        {
            this.context = c;
        }

        public IEnumerable<Author> All()
        {
            return context.Authors;
        }

        public void AddAuthor(Author a)
        {
            context.Authors.Add(a);
            context.SaveChanges();
        }

        public void DeleteAuthor(Author a)
        {
            context.Authors.Remove(a);
        }
    }
}
