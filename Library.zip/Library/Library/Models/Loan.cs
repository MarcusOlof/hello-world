﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Models
{
    class Loan
    {
        public BookCopy loanBookCopy { get; set; }
        public Member member { get; set; }
        public int ID { get; set; }
        public DateTime loanDate { get; set; }
        public DateTime dueDate { get; set; } // tänker att man sätter denna till typ 30 dagar(max antal dagar man får låna en bok)
        public DateTime returnDate { get; set; } // vet inte om den ska va datetime men tanken är att ta starttime + duetime = endtime;

        // en bok ska vara kopplad till ett lån
        // ett lån ska även vara kopplat till en användare
        public Loan()
        {

        }

        public Loan(Member _member, DateTime _loanDate, DateTime _dueDate, BookCopy _loanBookCopy, DateTime _returnDate) // ska innehålla en author
        {
            member = _member;
            loanDate = _loanDate;
            dueDate = _dueDate;
            loanBookCopy = _loanBookCopy;
            returnDate = _returnDate;
        }
        public override string ToString()
        {
            return String.Format("[{0}] -- {1} -- {2}", ID, loanBookCopy.book1, loanDate, member.Name);
        }
    }
}
