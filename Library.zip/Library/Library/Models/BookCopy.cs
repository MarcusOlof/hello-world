﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Models
{
    public class BookCopy
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public Book book1 { get; set; }
        
        public BookCopy()
        {
        }
        public override string ToString()
        {
            return String.Format("[{0}] ", ID);
        }
    }
}
