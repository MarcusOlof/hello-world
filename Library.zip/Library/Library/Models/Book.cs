﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Library.Models {
    public class Book {

        //public virtual ICollection<Author> AuthorList { get; set; }
        public virtual ICollection<BookCopy> BookCopyList { get; set; }

        public int i { get; set; }
        [Key]
        public int ID { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string ISBN { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public virtual Author Author { get; set; }

        public Book()
        {
        
        }

        public Book(string _Title, string _ISBN, string _Description, Author _author) // ska innehålla en author
        {
                Title = _Title;
                ISBN = _ISBN;
                Description = _Description;
                Author = _author;
        }

        /// <summary>
        /// Useful for adding the book objects directly to a ListBox.
        /// </summary>
        public override string ToString() {
            return String.Format("[{0}] -- {1} -- {4} -- {5}", ID, Title, ISBN, Description, Author, BookCopyList.Count - i);
        }
    }
}