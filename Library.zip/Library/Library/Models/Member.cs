﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Models
{
    class Member
    {

        public virtual ICollection<Loan> LoanList { get; set; }

        public int ID { get; set; }
        public string personalNmr { get; set; }
        public string Name { get; set; }

        // en medlem ska kunna ha 0-flera lån

        //public Member(int inID, string inPersonalNmr, string inName)
        //{
        //    this.ID = inID;
        //    this.personalNmr = inPersonalNmr;
        //    this.Name = inName;
        //}

        public override string ToString()
        {
            return String.Format("[{0}] -- {1} -- {2}", this.ID, this.Name, this.personalNmr);
        }
    }
}
