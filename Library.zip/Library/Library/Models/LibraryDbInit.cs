﻿using Library.Services;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Models {
    /// <summary>
    /// Database strategy is chosen as the base class to LibraryDbInit.
    /// Here in the Seed method you can create the default objects you want in the database.
    /// </summary>
    class LibraryDbInit : DropCreateDatabaseAlways<LibraryContext> {
        protected override void Seed(LibraryContext context) {
            base.Seed(context);

            Member member1 = new Member()
            {
                Name = "Bengt",
                personalNmr = "1234"
            };

            Member member2 = new Member()
            {
                Name = "Matti",
                personalNmr = "5544"
            };

            Author MarcusOlofsson = new Author()
            {
                ID = 1,
                Name = "Marcus Olofsson"
            };
            Author Goran = new Author()
            {
                ID = 2,
                Name = "Göran"
            };

            Book bok = new Book("Mackans bok", "1234-1234", "Its about an amazing person called mackan", MarcusOlofsson);
            //{
            //    ID = 1,
            //    Title = "Mackans bok",
            //    ISBN = "1234-1234",
            //    Description = "Its about an amazing person called mackan",
            //    Author = MarcusOlofsson
            //};
            Book bok1 = new Book("Robins Bok", "123", "En JÄVLIGT DÅLIG BOK", Goran);
            //{
            //    ID = 2,
            //    Title = "Robins Bok",
            //    ISBN = "123",
            //    Description = "En JÄVLIGT DÅLIG BOK",
            //    Author = Goran
            //};
            // Add the book to the DbSet of books.
            
            context.Books.Add(bok);
            context.Books.Add(bok1);
            context.Members.Add(member1);
            context.Members.Add(member2);
            // Persist changes to the database
            context.SaveChanges();
        }
    }
}
