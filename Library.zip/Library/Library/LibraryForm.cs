﻿using Library.Models;
using Library.Repositories;
using Library.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class LibraryForm : Form
    {
            
        BookService bookService;
        LoanService loanService;
        MemberService memberService;
        AuthorService authorService;
        BookCopyService bookCopyService;
        public LibraryForm()
        {
            InitializeComponent();

            // we create only one context in our application, which gets shared among repositories
            LibraryContext context = new LibraryContext();
            // we use a factory object that will create the repositories as they are needed, it also makes
            // sure all the repositories created use the same context.
            RepositoryFactory repFactory = new RepositoryFactory(context);

            this.loanService = new LoanService(repFactory);
            this.bookService = new BookService(repFactory);
            this.authorService = new AuthorService(repFactory);
            this.bookCopyService = new BookCopyService(repFactory);
            this.memberService = new MemberService(repFactory);

            ShowAllBooks(bookService.All());
            ShowAllLoans(loanService.All());

            // observers
            bookService.Updated += OnChanged;
            authorService.Updated += OnChanged;
            memberService.Updated += OnChanged;
            loanService.Updated += OnChanged;
            bookCopyService.Updated += OnChanged;
        }

        /// <summary>
        /// A observer event
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="args">
        /// Event data
        /// </param>
        private void OnChanged(object sender, EventArgs args)
        {
            ShowAllBooks(bookService.All());
            ShowAllLoans(loanService.All());
        }
        /// <summary>
        /// Shows all books in database
        /// </summary>
        /// </param>
        /// <param name="books">
        /// IEnumerable list that gets book objects from database
        /// </param>
        private void ShowAllBooks(IEnumerable<Book> books)
        {

            lbBooks.Items.Clear();
            int counter = 0;
            
            foreach (Book book in books)
            {
                
                    foreach (BookCopy bc in book.BookCopyList)
                    {
                        if (loanService.IsBookCopyLoaned(bc) == true)
                        {
                            counter++;
                        }
                    }
            
                book.i = counter;
                lbBooks.Items.Add(book);
            }
        }
        /// <summary>
        /// Shows all loans in database
        /// </summary>
        /// <param name="loans">
        /// IEnumerable list that gets all the loan objects in database
        /// </param>
        private void ShowAllLoans(IEnumerable<Loan> loans)
        {
            lbLoans.Items.Clear();
            DateTime defaultLoanDate = DateTime.Parse("1900-01-01");
            foreach (Loan loan in loans)
            {
                if (loan.returnDate == defaultLoanDate)
                {
                    lbLoans.Items.Add(loan);
                }
            }
        }
        /// <summary>
        /// Checking if the value in the textbox is the correct value
        /// </summary>
        /// <param name="Expression">
        /// a object from a textbox
        /// </param>
        public static bool IsDate(object Expression)
        {
            if (Expression != null)
            {
                if (Expression is DateTime)
                {
                    return true;
                }
                if (Expression is string)
                {
                    DateTime time1;
                    return DateTime.TryParse((string)Expression, out time1);
                }
            }
            return false;
        }

        /// <summary>
        /// Checking if the value in the textbox is the correct value
        /// </summary>
        /// <param name="s">
        /// a string from a textbox
        /// </param>
        public bool IsNumeric(string s)
        {
            float output;
            return float.TryParse(s, out output);
        }
        /// <summary>
        /// Show the form for adding a book
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void AddBooksBtn_Click(object sender, EventArgs e)
        {
            AddBookForm addBookForm = new AddBookForm(bookService);
            
            addBookForm.Show();
        }

        public void lbBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        /// <summary>
        /// Shows the form for loaning a book
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void LoanbookBtn_Click(object sender, EventArgs e)
        {

            LoanBookForm loanBookForm = new LoanBookForm(bookService, memberService, loanService);

            loanBookForm.Show();
        }
        /// <summary>
        /// Shows the books written by a specific author
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void BooksByAuthorBtn_Click(object sender, EventArgs e)
        {
            lbBooksByAuthor.Items.Clear();
            foreach (Book b in bookService.BooksByAuthor(BooksByAuthorTxtBox.Text))
            {
                lbBooksByAuthor.Items.Add(b);
            }
        }
        /// <summary>
        /// Modify copies of the chosen book-object in the list
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void ModifyBookCopiesBtn_Click(object sender, EventArgs e)
        {
            if (lbBooks.SelectedItem == null)
            {
                MessageBox.Show("Ingen ändring kommer ske eftersom ingen bok är markerad i listan");
            }
            else if (ModifyTxtBox.Text == "")
            {
                MessageBox.Show("Ingen ändring kommer ske eftersom inget värde är angivit i textfältet");
            }
            else if (IsNumeric(ModifyTxtBox.Text) != true)
            {
                MessageBox.Show("Ingen ändring kommer ske eftersom att det angivna värde måste vara en siffra");
            }
            else
            {
                MessageBox.Show("En ändring av bok-kopior har genomoförts");
                bookService.ModifyBookCopies((Book)lbBooks.SelectedItem, ModifyTxtBox.Text);
                ModifyTxtBox.Text = "";
            }
        }

        private void ModifyTxtBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void BooksByAuthorTxtBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }

        private void lbLoans_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        /// <summary>
        /// Shows the form for adding a member
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void AddMemberBtn_Click(object sender, EventArgs e)
        {
            AddMemberForm addMemberForm = new AddMemberForm(memberService);
            
            addMemberForm.Show();
        }

        //Ändrar datumet på när ett lån utfördes
        /// <summary>
        /// Modifies the date of when a book is loaned
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void ModifyLoanDateBtn_Click(object sender, EventArgs e)
        {
            if (lbLoans.SelectedItem == null)
            {
                MessageBox.Show("Ingen ändring kommer att ske eftersom att ingen bok ur lånlistan är markerad");
            }
            else if (ModifyLoanDateTxtBox.Text == "")
            {
                MessageBox.Show("Ingen ändring kommer att ske eftersom att inget datum är angivit");
            }
            else if (IsDate(ModifyLoanDateTxtBox.Text) != true)
            {
                MessageBox.Show("Ingen ändring kommer att ske eftersom du måste ange ett riktigt datum(yyyy-mm-dd)");
            }
            else
            {
                MessageBox.Show("Datumet har nu uppdaterats");
                loanService.ModifyLoanDate((Loan)lbLoans.SelectedItem, ModifyLoanDateTxtBox.Text);
                ModifyLoanDateTxtBox.Text = "";
                ShowAllLoans(loanService.All());
            }
        }

        private void ModifyLoanDateTxtBox_TextChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// Returns a book copy so it can be loaned again
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void ReturnBookBtn_Click(object sender, EventArgs e)
        {
            if (lbLoans.SelectedItem == null)
            {
                MessageBox.Show("Ingen bok ur lånelistan var markerad och därför kommer inte återlämningen att ske");
            }
            else
            {
                Loan l = new Loan();
                foreach (Loan loan in loanService.All())
                {

                    if (loan == lbLoans.SelectedItem)
                    {
                        loan.returnDate = DateTime.Now;
                        double days = (loan.dueDate - loan.returnDate).TotalDays;
                        if (loan.returnDate > loan.dueDate)
                        {
                            double fine = days * 10;
                            int fine1 = Convert.ToInt32(fine * -1);
                            int days1 = Convert.ToInt32(days * -1);
                            MessageBox.Show("Boken är " + days1 + "dagar försenad och avgiften ligger på: " + fine1 + "kr");
                        }
                        else
                        {
                            l = loan;
                            MessageBox.Show("Du har återlämnat boken: " + loan.loanBookCopy.book1.Title);

                            lbLoans.Items.Clear();

                        }
                    }
                }
                loanService.Edit(l);
            }
        }

        private void MemberLoansTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoansByMemberBtn_Click(object sender, EventArgs e)
        {
            if (MemberLoansTxtBox.Text == "")
            {
                MessageBox.Show("Du måste fylla i text fältet med ett namn på en member");
            }
            else
            {
                lbLoansByMember.Items.Clear();
                foreach (Loan l in loanService.LoansByMember(MemberLoansTxtBox.Text))
                {
                    lbLoansByMember.Items.Add(l);
                }
            }
        }
    }
}
