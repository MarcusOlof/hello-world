﻿namespace Library
{
    partial class AddBookForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TitleTxtBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ISBNTxtBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.DescriptionTxtBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.AuthorTxtBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CopiesTxtBox = new System.Windows.Forms.TextBox();
            this.addBookBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TitleTxtBox
            // 
            this.TitleTxtBox.Location = new System.Drawing.Point(45, 2);
            this.TitleTxtBox.Name = "TitleTxtBox";
            this.TitleTxtBox.Size = new System.Drawing.Size(225, 22);
            this.TitleTxtBox.TabIndex = 1;
            this.TitleTxtBox.TextChanged += new System.EventHandler(this.TitleTxtBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(0, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "ISBN";
            // 
            // ISBNTxtBox
            // 
            this.ISBNTxtBox.Location = new System.Drawing.Point(45, 35);
            this.ISBNTxtBox.Name = "ISBNTxtBox";
            this.ISBNTxtBox.Size = new System.Drawing.Size(225, 22);
            this.ISBNTxtBox.TabIndex = 3;
            this.ISBNTxtBox.TextChanged += new System.EventHandler(this.ISBNTxtBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(0, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Description";
            // 
            // DescriptionTxtBox
            // 
            this.DescriptionTxtBox.Location = new System.Drawing.Point(85, 72);
            this.DescriptionTxtBox.Name = "DescriptionTxtBox";
            this.DescriptionTxtBox.Size = new System.Drawing.Size(185, 22);
            this.DescriptionTxtBox.TabIndex = 5;
            this.DescriptionTxtBox.TextChanged += new System.EventHandler(this.DescriptionTxtBox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Author";
            // 
            // AuthorTxtBox
            // 
            this.AuthorTxtBox.Location = new System.Drawing.Point(56, 112);
            this.AuthorTxtBox.Name = "AuthorTxtBox";
            this.AuthorTxtBox.Size = new System.Drawing.Size(214, 22);
            this.AuthorTxtBox.TabIndex = 7;
            this.AuthorTxtBox.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Copies";
            // 
            // CopiesTxtBox
            // 
            this.CopiesTxtBox.Location = new System.Drawing.Point(56, 148);
            this.CopiesTxtBox.Name = "CopiesTxtBox";
            this.CopiesTxtBox.Size = new System.Drawing.Size(214, 22);
            this.CopiesTxtBox.TabIndex = 9;
            this.CopiesTxtBox.TextChanged += new System.EventHandler(this.CopiesTxtBox_TextChanged);
            // 
            // addBookBtn
            // 
            this.addBookBtn.Location = new System.Drawing.Point(3, 189);
            this.addBookBtn.Name = "addBookBtn";
            this.addBookBtn.Size = new System.Drawing.Size(267, 52);
            this.addBookBtn.TabIndex = 10;
            this.addBookBtn.Text = "Add Book";
            this.addBookBtn.UseVisualStyleBackColor = true;
            this.addBookBtn.Click += new System.EventHandler(this.addBookBtn_Click);
            // 
            // AddBookForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Controls.Add(this.addBookBtn);
            this.Controls.Add(this.CopiesTxtBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.AuthorTxtBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.DescriptionTxtBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ISBNTxtBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TitleTxtBox);
            this.Controls.Add(this.label1);
            this.Name = "AddBookForm";
            this.Text = "AddBookForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TitleTxtBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ISBNTxtBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox DescriptionTxtBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox AuthorTxtBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox CopiesTxtBox;
        private System.Windows.Forms.Button addBookBtn;
    }
}