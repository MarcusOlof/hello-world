﻿using Library.Models;
using Library.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    partial class AddMemberForm : Form
    {
        MemberService memberService;
        public AddMemberForm(MemberService memberService)
        {
            InitializeComponent();

            this.memberService = memberService;
        }

        private void MemberNameTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void MemberPersonalNmrTxtBox_TextChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// adds a member to the database
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void MemberAddMemberBtn_Click(object sender, EventArgs e)
        {
            if (MemberNameTxtBox.Text == "")
            {
                MessageBox.Show("Användaren kommer inte bli skapad eftersom att namn fältet inte är ifyllt");
            }
            if (MemberPersonalNmrTxtBox.Text == "")
            {
                MessageBox.Show("Användaren kommer inte bli skapad eftersom att personnummer fältet inte är ifyllt");
            }
            else
            {


                Member member = new Member()
                {
                    Name = MemberNameTxtBox.Text,
                    personalNmr = MemberPersonalNmrTxtBox.Text
                };
                memberService.AddMember(member);

                this.Hide();
            }
        }
    }
}
