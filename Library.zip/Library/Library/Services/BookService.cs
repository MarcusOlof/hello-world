﻿using Library.Models;
using Library.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    class BookService : IService
    {
        /// <summary>
        /// service doesn't need a context but it needs a repository.
        /// </summary>
        BookRepository bookRepository;
        public event EventHandler Updated;

        /// <param name="rFactory">A repository factory, so the service can create its own repository.</param>
        public BookService(RepositoryFactory rFactory)
        {
            this.bookRepository = rFactory.CreateBookRepository();
        }

        /// <summary>
        /// OnChanged event launched when changes is made 
        /// </summary>
        /// <param name="args">Event arguments, placeholder for future use</param>
        protected virtual void OnChanged(EventArgs args)
        {
            Updated?.Invoke(this, args);
        }

        public IEnumerable<Book> All()
        {
            return bookRepository.All();
        }

        public void AddBook(Book b)
        {
            if (b != null)
            {
                bookRepository.AddBook(b);
                OnChanged(EventArgs.Empty);
            }
            else
            {
                throw new ArgumentNullException();
            }
            
        }

        public void DeleteBook(Book b)
        {
            if (b != null)
            {
                bookRepository.DeleteBook(b);
                OnChanged(EventArgs.Empty);
            }
            else
            {
                throw new ArgumentNullException();
            }
        }

        public IEnumerable<Book> BooksByAuthor(string name)
        {
            return (from books in bookRepository.All() where books.Author.Name == name select books);
        }

        public IEnumerable<Book> GetAllThatContainsInTitle(string a)
        {
            return from b in bookRepository.All()
            where b.Title.Contains(a)
            select b;
        }

        public void ModifyBookCopies(Book b, string modifyValue)
        {
            int ModifyCopies = Int32.Parse(modifyValue);
            foreach (Book b1 in bookRepository.All())
            {
                if (b1 == b)
                {
                    b.BookCopyList.Clear();
                    for (int i = 0; i < ModifyCopies; i++)
                    {
                        BookCopy bookCopy = new BookCopy()
                        {
                            book1 = b
                        };
                        b.BookCopyList.Add(bookCopy);
                    }
                }
            }
            OnChanged(EventArgs.Empty);
        }

        public IEnumerable<Book> GetAllBooksFromAuthor(string a)
        {
            return from b in bookRepository.All()
                   where a.Equals(b.Author)
                   select b;
        }
        
        /// <summary>
        /// The Edit method makes sure that the given Book object is saved to the database and raises the Updated() event.
        /// </summary>
        /// <param name="b"></param>
        public void Edit(Book b)
        {
            if(b != null)
            {
                bookRepository.Edit(b);
                OnChanged(EventArgs.Empty);
            }
            else
            {
                throw new ArgumentNullException();
            }
        }

        
    }
    }

