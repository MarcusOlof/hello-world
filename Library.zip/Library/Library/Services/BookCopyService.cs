﻿using Library.Models;
using Library.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    class BookCopyService
    {
                /// <param name="rFactory">A repository factory, so the service can create its own repository.</param>
        public BookCopyService(RepositoryFactory rFactory)
        {
            this.bookCopyRepository = rFactory.CreateBookCopyRepository();
        }
        BookCopyRepository bookCopyRepository;

        public IEnumerable<BookCopy> All()
            {
            return bookCopyRepository.All();
            }
        public event EventHandler Updated;
        /// <summary>
        /// OnChanged event launched when changes is made 
        /// </summary>
        /// <param name="args">Event arguments, placeholder for future use</param>
        protected virtual void OnChanged(EventArgs args)
        {
            Updated?.Invoke(this, args);
        }
    }
}
