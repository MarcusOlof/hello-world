﻿using Library.Models;
using Library.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    class AuthorService
    {
        /// <param name="rFactory">A repository factory, so the service can create its own repository.</param>
        public AuthorService(RepositoryFactory rFactory)
        {
            this.authorRepository = rFactory.CreateAuthorRepository();
        }
        AuthorRepository authorRepository;

        public IEnumerable<Author> All()
        {
            return authorRepository.All();
        }
        public void AddAuthor(Author a)
        {
            authorRepository.AddAuthor(a);
        }

        public void DeleteAuthor(Author a)
        {
            authorRepository.DeleteAuthor(a);
        }
        public event EventHandler Updated;
        /// <summary>
        /// OnChanged event launched when changes is made 
        /// </summary>
        /// <param name="args">Event arguments, placeholder for future use</param>
        protected virtual void OnChanged(EventArgs args)
        {
            Updated?.Invoke(this, args);
        }
    }
}
