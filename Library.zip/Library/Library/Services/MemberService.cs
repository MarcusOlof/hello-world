﻿using Library.Models;
using Library.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    class MemberService : IService
    {
        /// <param name="rFactory">A repository factory, so the service can create its own repository.</param>
        public MemberService(RepositoryFactory rFactory)
        {
            this.memberRepository = rFactory.CreateMemberRepository();
        }
        MemberRepository memberRepository;

        public IEnumerable<Member> All()
        {
            return memberRepository.All();
        }

        public void AddMember(Member m)
        {
            memberRepository.AddMember(m);
        }

        public event EventHandler Updated;
        /// <summary>
        /// OnChanged event launched when changes is made 
        /// </summary>
        /// <param name="args">Event arguments, placeholder for future use</param>
        protected virtual void OnChanged(EventArgs args)
        {
            Updated?.Invoke(this, args);
        }
    }
    }

