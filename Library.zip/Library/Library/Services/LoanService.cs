﻿using Library.Models;
using Library.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.Services
{
    class LoanService : IService
    {

        LoanRepository loanRepository;

        public event EventHandler Updated;

        /// <param name="rFactory">A repository factory, so the service can create its own repository.</param>
        public LoanService(RepositoryFactory rFactory)
        {
            this.loanRepository = rFactory.CreateLoanRepository();
        }
        
        /// <summary>
        /// OnChanged event launched when changes is made 
        /// </summary>
        /// <param name="args">Event arguments, placeholder for future use</param>
        protected virtual void OnChanged(EventArgs args)
        {
            Updated?.Invoke(this, args);
        }
        // kollar om boken är utlånad eller om den är ledig
        public bool IsBookCopyLoaned(BookCopy bc)
        {
            bool bookcopyloaned = false;
            DateTime tempReturnDate = DateTime.Parse("1900-01-01");
            foreach (Loan l in loanRepository.All())
            {
                if (l.loanBookCopy == bc && l.returnDate == tempReturnDate) //returnDate ska vara default date (kopian är fortfarande utlånad)..
                {
                    bookcopyloaned = true;
                }
            }
            return bookcopyloaned;
        }

        public void ModifyLoanDate(Loan l, string newDate)
        {
            DateTime ModifiedLoanDate = DateTime.Parse(newDate);
            
            l.loanDate = ModifiedLoanDate;
                   
            loanRepository.Edit(l);
            OnChanged(EventArgs.Empty);
        }

        public IEnumerable<Loan> All()
        {
            return loanRepository.All();
        }

        public void AddLoan(Loan l)
        {
            loanRepository.AddLoan(l);
            OnChanged(EventArgs.Empty);
        }

        public void DeleteLoan(Loan l)
        {
            loanRepository.DeleteLoan(l);
            OnChanged(EventArgs.Empty);
        }

        public void Edit(Loan l)
        {
            loanRepository.Edit(l);
            OnChanged(EventArgs.Empty);
        }

        public IEnumerable<Loan> LoansByMember(string name)
        {
            return (from loans in loanRepository.All() where loans.member.Name == name select loans);
        }
    }
    }

