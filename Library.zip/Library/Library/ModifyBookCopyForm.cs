﻿using Library.Models;
using Library.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    partial class ModifyBookCopyForm : Form
    {
        BookService bookService;
        public ModifyBookCopyForm(BookService bookService)
        {
            InitializeComponent();

            this.bookService = bookService;
        }

        private void BookCopyTitleTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ModifyBookCopyNmrTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ModiftBookCopyBtn_Click(object sender, EventArgs e)
        {
            //Book b = new Book();
            //int ModifyBookCopies = Int32.Parse(ModifyBookCopyNmrTxtBox.Text);
            //foreach (Book b in bookService.All())
            //{
            //    if (b.Title != BookCopyTitleTxtBox.Text)
            //    {
            //        MessageBox.Show("Boken finns inte i biblioteket!");
            //    }
            //    else if (b.Title == BookCopyTitleTxtBox.Text)
            //    {
            //        b.BookCopyList.Clear();

            //        if (b.BookCopyList.Count() == ModifyBookCopies)
            //        {

            //        }
            //        else
            //        {
            //            b.BookCopyList.
            //        }
            //    }
            //}
        }
    }
}
