﻿using Library.Models;
using Library.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    partial class LoanBookForm : Form
    {
        BookService bookService;
        MemberService memberService;
        LoanService loanService;
        public LoanBookForm(BookService bookService, MemberService memberService, LoanService loanService)
        {
            InitializeComponent();

            this.bookService = bookService;
            this.memberService = memberService;
            this.loanService = loanService;

            ShowAllBooks(bookService.All());
            foreach (Member member in memberService.All())
            {
            MembersComboBox.Items.Add(member);
        }
    }
        /// <summary>
        /// Shows all the books in the database
        /// </summary>
        /// <param name="books">
        /// IEnumerable list that countains all books in the database
        /// </param>
        private void ShowAllBooks(IEnumerable<Book> books)
        {
            lbAllBooks.Items.Clear();
            foreach (Book book in books)
            {
                lbAllBooks.Items.Add(book);
            }
        }

        public static bool IsDate(object Expression)
        {
            if (Expression != null)
            {
                if (Expression is DateTime)
                {
                    return true;
                }
                if (Expression is string)
                {
                    DateTime time1;
                    return DateTime.TryParse((string)Expression, out time1);
                }
            }
            return false;
        }

        private void LoanBookTxtBox_TextChanged(object sender, EventArgs e)
        {
            
        }
        /// <summary>
        /// Loans a book and sets it to loaned
        /// </summary>
        /// <param name="sender">
        /// Object reference
        /// </param>
        /// <param name="e">
        /// Event data
        /// </param>
        private void LoanBookBtn_Click(object sender, EventArgs e)
        {
            Book book = (Book)lbAllBooks.SelectedItem;
            BookCopy bookCopy = null;
            if (book == null)
            {
                MessageBox.Show("Lånet kommer inte genomföras eftersom ingen bok var markerad");
            }
            else if (LoanDateTxtBox.Text == "")
            {
                MessageBox.Show("Lånet kommer inte genomföras eftersom inget låne-datum skrevs");
            }
            else if (MembersComboBox.Text == "")
            {
                MessageBox.Show("Lånet kommer inte genomföras eftersom ingen användare var markerad");
            }
            else if (IsDate(LoanDateTxtBox.Text) != true)
            {
                MessageBox.Show("Lånet kommer inte genomföras eftersom du måste ange ett riktigt datum(yyyy-mm-dd)");
            }
            else
            {
                foreach (BookCopy bc in book.BookCopyList)
                {
                    if (loanService.IsBookCopyLoaned(bc) != true)
                    {
                        bookCopy = bc;
                    }
                }
                DateTime tempReturnDate = DateTime.Parse("1900-01-01");

                DateTime LoanDate = DateTime.Parse(LoanDateTxtBox.Text); // vet inte hur jag ska få så att en användare bara kan skriva i datumformat
                if (bookCopy != null)
                {
                    Loan loan = new Loan((Member)MembersComboBox.SelectedItem, LoanDate, LoanDate.AddDays(15), bookCopy, tempReturnDate);
                    loanService.AddLoan(loan);
                }
                else
                {
                    MessageBox.Show("Det fanns inga lediga kopior av denna bok");
                }
                this.Hide();
            }
        }

        private void lbAllBooks_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void MembersComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void LoanDateTxtBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
