/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycarshop;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Testing my methods
 *
 * @author Marcus Olofsson Version@ 2017-01-15
 */
public class VerkstadTest {

    public VerkstadTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of serviceMeddelande method, of class Verkstad.
     */
    @Test
    public void testServiceMeddelande() {
        System.out.println("serviceMeddelande");
        int inMil = 10000;
        Workshop instance = new Workshop();
        String expResult = "Medium service rekommenderas";
        String result = instance.serviceMessage(inMil);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

    /**
     * Test of tidAttLaga method, of class Verkstad.
     */
    @Test
    public void testTidAttLaga() {
        System.out.println("tidAttLaga");
        int inMil = 4500;
        Workshop instance = new Workshop();
        int expResult = 3;
        int result = instance.timeToFix1(inMil);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.

    }

}
