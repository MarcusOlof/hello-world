package mycarshop;

/**
 * represent a car
 *
 * @author Marcus Olofsson
 * @Version 2017-01-13
 */
public class Car extends Vehicles {

    /**
     * @param regNummer String, Register a regnumber
     * @param bilMarke String, Register a brand
     * @param arsModell String, Register a tearmodel
     * @param namn String, Register an owner
     * @param mil int, Register how long the car has drove
     * @param rättDatum String, Register a date when the vehicle gets to the workshop
     * @param laga int, Register a approximate time when the vehicle is ready
     * @param meddelande String, Register a recommended service message
     * @param fordonsTyp String, Register the type of vehicle 
     */
    private String vehicleType = "Bil";

    public Car(String regNumber, String brand, String yearmodel, String owner, int mile, String fixedDate, int timeToFix, String message, String vehicleType) {
        super(regNumber, brand, yearmodel, owner, mile, fixedDate, timeToFix, message, vehicleType);
    }

    public String getVehicleType() {
        return vehicleType;
    }
}
