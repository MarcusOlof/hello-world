package mycarshop;

import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.JOptionPane;

/**
 * Creates an object
 *
 * @author Marcus Olofsson
 * @Version 2017-01-13
 */
public class Workshop {

    ArrayList<Vehicles> allVehicles;

    private static FileWriterReader fwr = new FileWriterReader();

    /**
     * reads object from file and puts it in the allvehicles list and if the list is empty it creates an empty list
     */
    public Workshop() {
        allVehicles = (ArrayList<Vehicles>) fwr.readObject("motorfordon.ser");
        if (allVehicles == null) {
            allVehicles = new ArrayList<Vehicles>();
        }

    }

    /**
     * register vehicles to a list
     */
    public void registerVehicles() {

        int newVehicle = 0;

        while (newVehicle == 0) {

            String date = Calendar.getInstance().getTime().toString();         // initierar variabeln datum med datum och tid

            String fixedDate = date.substring(0, 11);                                 // tur ut nödvändigt block och initierar till variabeln rDatum

            int mile = vehicleDroven();
            int timeToFix = timeToFix1(mile);
            String message = serviceMessage(mile);

            String regNumber = JOptionPane.showInputDialog(null, "Registreringsnummer: ");          // sparar registringsnumret i variabeln regNummer
            String brand = JOptionPane.showInputDialog(null, "märke: ");            // sparar bilmärket i variebeln bilMarke
            String yearModel = JOptionPane.showInputDialog(null, "Årsmodell: ");          // sparar årsmodellen i variabeln arsModell
            String owner = JOptionPane.showInputDialog(null, "Ägare(Förnamn, Efternamn): ");// sparar förnamn och efternamn i variabeln
            String vehicleType = (String) JOptionPane.showInputDialog(null, "Registrera fordon",
                    "Typ av fordon ",
                    JOptionPane.QUESTION_MESSAGE, null, new String[]{
                        "Bil",
                        "Lastbil",
                        "Motorcykel",}, "Bil");

            switch (vehicleType) {
                case "Bil":
                    Vehicles vehicle = new Car(regNumber, brand, yearModel, owner, mile, fixedDate, timeToFix, message, vehicleType);
                    allVehicles.add(vehicle);

                    break;
                case "Lastbil":
                    vehicle = new Truck(regNumber, brand, yearModel, owner, mile, fixedDate, timeToFix, message, vehicleType);
                    allVehicles.add(vehicle);
                    break;
                case "Motorcykel":
                    vehicle = new Motorcycle(regNumber, brand, yearModel, owner, mile, fixedDate, timeToFix, message, vehicleType);
                    allVehicles.add(vehicle);
                    break;
            }

            JOptionPane.showMessageDialog(null, vehicleType + " " + regNumber + " är tillagd");

            newVehicle = JOptionPane.showConfirmDialog(null, "Vill du mata in fler fordon? ");
        }
        fwr.writeObjects(allVehicles, "motorfordon.ser");
    }

    /**
     * search for a vehicle and looks if it exists
     */
    public void search() {
        Vehicles vehicles = searchVehicles();
        if (vehicles == null) {
            return;
        }
        JOptionPane.showMessageDialog(null, information(vehicles));

    }

    /**
     * Adds work done
     */
    public void WorkDone() {

        int totalCost = 0;
        Vehicles vehicles = searchVehicles();

        if (vehicles == null) {
            return;
        }

        String workDone = (String) JOptionPane.showInputDialog(null, "Registrera utfört arbete ", // dropdown menu om vilket jobb som är utfört
                "Typ av arbete ",
                JOptionPane.QUESTION_MESSAGE, null, new String[]{
                    "Premium Service",
                    "Medium Service",
                    "Budget Service",
                    "Lackering",
                    "Däckbyte",
                    "Besiktning",}, "Premium Service");

        switch (workDone) {
            case "Premium Service":
                totalCost += 4000;
                break;
            case "Medium Service":
                totalCost += 3000;
                break;
            case "Budget Service":
                totalCost += 2000;
                break;
            case "Lackering":
                totalCost += 1500;
                break;
            case "Däckbyte":
                totalCost += 1000;
                break;
            case "Besiktning":
                totalCost += 800;
                break;
            default:
                break;
        }

        vehicles.getWork().add(workDone);                              // lägger till ufört arbete till valtfordon
        vehicles.setTotalCost(totalCost + vehicles.getTotalCost());
        JOptionPane.showMessageDialog(null, "arbetet " + vehicles.getWork() + " har utförts på fordon " + vehicles.getRegNumber());
        fwr.writeObjects(allVehicles, "motorfordon.ser");

    }

    /**
     * search for a vehicle
     * @return Object - returns a specific vehicle
     */
    public Vehicles searchVehicles() {
        boolean vehicleExist = false;
        Vehicles chosenVehicle = null;
        String regNumber = (String) JOptionPane.showInputDialog("Skriv in regnummret du letar efter: ");
        for (Vehicles vehicles : allVehicles) {
            if (regNumber.equalsIgnoreCase(vehicles.getRegNumber())) {                                           // hoppar ur om den inte hittar fordon i fordons listan
                vehicleExist = true;
                chosenVehicle = vehicles;
            }
        }
        if (vehicleExist == false) {
            JOptionPane.showMessageDialog(null, regNumber + " finns inte i listan");
        }
        return chosenVehicle;
    }

    /**
     * deletes object/ vehicle from list
     */
    public void CheckOutVehicles() {

        if (allVehicles.isEmpty()) {                                               // hoppar ur om den inte hittar fordon i fordons listan
            JOptionPane.showMessageDialog(null, "Det finns inga fordon att checka ut");
            return;
        }

        Vehicles vehicles = searchVehicles();

        if (vehicles != null) {
            allVehicles.remove(vehicles);                                          // tar bort objekt från arraylist
            JOptionPane.showMessageDialog(null, vehicles.getRegNumber() + " är utcheckad\n totalkostnaden: " + vehicles.getTotalCost());
        }
        fwr.writeObjects(allVehicles, "motorfordon.ser");
    }

    /**
     * Move vihicles to ready for pickup
     */
    public void moveVehicleToPickup() {

        if (allVehicles.isEmpty()) {                                               // hoppar ur om den inte hittar fordon i fordons listan
            JOptionPane.showMessageDialog(null, "Det finns inga fordon incheckade");
            return;
        }

        Vehicles vehicle1 = null;
        Vehicles vehicle = searchVehicles();
        if (vehicle == null) {
            return;
        }
        vehicle.setReadyForPickup(true);
        vehicle1 = vehicle;

        JOptionPane.showMessageDialog(null, vehicle.getVehicleType() + " " + vehicle.getRegNumber() + " är färdig att hämtas");
        fwr.writeObjects(allVehicles, "motorfordon.ser");
    }

    /**
     * shows recommended service
     *
     * @param inMil - random number between 1500 - 40000
     * @return String - recommended service message
     */
    public String serviceMessage(int inMil) {                               // tur ut nödvändigt block och initierar till variabeln rDatum

        String message = "";
        if (inMil > 499 && inMil < 8001) {                                      //(if sats för att se vilken service som krävs.
            message = "Liten service rekommenderas";                                      //   jag sparar även meddelandena liten service, medium service och stor service 
        } else if (inMil > 8000 && inMil < 20001) {                             //   i variabeln meddelande beroende på vilket villkor som stämmer
            message = "Medium service rekommenderas";
        } else if (inMil > 20000 && inMil < 40001) {
            message = "Stor service rekommenderas";
        }
        return message;

    }

    /**
     * shows how long time the vehicle takes to fix
     *
     * @return int - how many days it takes to fix the vehicle
     */
    public int vehicleDroven() {                                 

        
        int mile = 1500 + (int) (Math.random() * 38500);                         // får ut ett randomtal mellan 1500 - 40000 som jag sparar i mil variabeln

        return mile;
    }

    public int timeToFix1(int inMil) {

        int timeToFix = inMil / 1500;
        return timeToFix;
    }

    /**
     * summarize all information
     *
     * @param vehicle - gets a speficic vehicle
     * @return String - writes all information about the vehicle
     */
    private String information(Vehicles vehicle) {
        String result = "Fordon som är inlämnade på verkstaden: \n"
                + "Typ av fordon: " + vehicle.getVehicleType()
                + "\n"
                + "registreringsnummer: " + vehicle.getRegNumber()
                + "\n"
                + "märke: " + vehicle.getBilMarke()
                + "\n"
                + "Årsmodell: " + vehicle.getArsModell()
                + "\n"
                + "Ägare: " + vehicle.getOwner()
                + "\n"
                + "inlämnad: " + vehicle.getFixedDate()
                + "\n"
                + "tid att laga: " + vehicle.getTimeToFix() + " dagar"
                + "\n"
                + "Mätarställning: " + vehicle.getMile() + " mil"
                + "\n"
                + "Service meddelande: " + vehicle.getMessage()
                + "\n"
                + "total Kostnad: " + vehicle.getTotalCost()
                + "\n \n";

        return result;
    }
}
