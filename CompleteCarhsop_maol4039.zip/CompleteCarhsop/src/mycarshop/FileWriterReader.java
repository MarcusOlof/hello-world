package mycarshop;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Saves to file
 *
 * @author Marcus Olofsson
 */
public class FileWriterReader {

    private File engineVehicle = new File("motorfordon.ser");

    /**
     * Reads object from file
     *
     * @param filename
     * @return objekt
     */
    public Object readObject(String filename) {
        Object object = null;

        try {
            FileInputStream fileIn = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(fileIn);
            object = in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException ioe) {
            System.out.println("Pang ioe " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Pang cnfe" + cnfe.getMessage());
        }
        return object;
    }

    /**
     * Write object to file
     *
     * @param object
     * @param filename
     */
    public void writeObjects(Object object, String filename) {
        FileOutputStream fileOut;
        try {
            fileOut = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(object);
            out.close();
            fileOut.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FileWriterReader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FileWriterReader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
