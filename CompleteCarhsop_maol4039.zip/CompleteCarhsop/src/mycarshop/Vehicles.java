package mycarshop;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Creates variables, a constructor, getters and setters
 * 
 * @author Marcus Olofsson
 * @Version 2017-01-13
 */
public class Vehicles implements Serializable {
    // tomma variablar
    private String regNumber;                                                       
    private String brand;
    private String yearModel;
    private String owner;
    private int mile;
    private String fixedDate;
    private int timeToFix;
    private String message;
    private String vehicleType;
    private List<String> work;
    private boolean readyForPickup;
    private int totalCost = 0;
     /**
     * creates a vehicles object
     * 
       * @param regNumber String, Register a regnumber
     * @param brand String, Register a brand
     * @param yearModel String, Register a tearmodel
     * @param owner String, Register an owner
     * @param mile int, Register how long the car has drove
     * @param fixedDate String, Register a date when the vehicle gets to the workshop
     * @param timeToFix int, Register a approximate time when the vehicle is ready
     * @param message String, Register a recommended service message
     * @param vehicleType String, Register the type of vehicle 
     
     */
    public Vehicles(String regNumber, String brand, String yearModel, String owner, int mile, String fixedDate, int timeToFix, String message, String veicleType) { //konstruktor
        this.regNumber = regNumber;
        this.brand = brand;
        this.yearModel = yearModel;
        this.owner = owner;
        this.mile = mile;
        this.fixedDate = fixedDate;
        this.timeToFix = timeToFix;
        this.message = message;
        this.vehicleType = veicleType;
        work = new ArrayList<>();
        this.readyForPickup = false;
    }

    public String getRegNumber() {    // getters
        return regNumber;
    }

    public String getBilMarke() {
        return brand;
    }

    public String getArsModell() {
        return yearModel;
    }

    public String getOwner() {
        return owner;
    }

    public int getMile() {
        return mile;
    }

    public String getFixedDate() {
        return fixedDate;
    }

    public int getTimeToFix() {
        return timeToFix;
    }

    public String getMessage() {
        return message;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public List<String> getWork() {
        return work;
    }

    public boolean isReadyForPickup() {
        return readyForPickup;
    }

    public int getTotalCost() {
        return totalCost;
    }

    public void setRegNummer(String regNummer) {      // setters
        this.regNumber = regNummer;
    }

    public void setBilMarke(String bilMarke) {
        this.brand = bilMarke;
    }

    public void setArsModell(String arsModell) {
        this.yearModel = arsModell;
    }

    public void setNamn(String namn) {
        this.owner = namn;
    }

    public void setMil(int mil) {
        this.mile = mil;
    }

    public void setRättDatum(String rättDatum) {
        this.fixedDate = rättDatum;
    }

    public void setLaga(int laga) {
        this.timeToFix = laga;
    }

    public void setMeddelande(String meddelande) {
        this.message = meddelande;
    }

    public void setArbeten(List<String> arbeten) {
        this.work = arbeten;
    }

    public void setReadyForPickup(boolean redoAttHämtas) {
        this.readyForPickup = redoAttHämtas;
    }

    public void setTotalCost(int totalKostnad) {
        this.totalCost = totalKostnad;
    }

}
