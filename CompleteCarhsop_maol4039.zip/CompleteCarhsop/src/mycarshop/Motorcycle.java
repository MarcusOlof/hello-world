package mycarshop;

/**
 * Represent a motorcycle
 *
 * @author Marcus Olofsson
 * @Version 2017-01-13
 */
public class Motorcycle extends Vehicles {

    
    private String vehicleType = "Motorcykel";
    /**
       * @param regNumber String, Register a regnumber
     * @param brand String, Register a brand
     * @param yearModel String, Register a tearmodel
     * @param owner String, Register an owner
     * @param mile int, Register how long the car has drove
     * @param fixedDate String, Register a date when the vehicle gets to the workshop
     * @param timeToFix int, Register a approximate time when the vehicle is ready
     * @param message String, Register a recommended service message
     * @param vehicleType String, Register the type of vehicle 
     */
    public Motorcycle(String regNumber, String brand, String yearModel, String owner, int mile, String fixedDate, int timeToFix, String message, String vehicleType) {
        super(regNumber, brand, yearModel, owner, mile, fixedDate, timeToFix, message, vehicleType);
    }
 public String getfordonsTyp() {
        return vehicleType;
}
}
